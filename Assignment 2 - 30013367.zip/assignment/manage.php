<?php include 'header.php'; ?>


<li class="navbar-brand"  >
                    <a class="nav-link" href="insert.php" >
                    ENTER NEW RECORD
                   
                    </a>
                </li>
<li class="navbar-brand"  >
                    <a class="nav-link" href="delete.php" >
                    DELETE A RECORD
                   
                    </a>
                </li>                
                
                <li class="navbar-brand"  >
                    <a class="nav-link" href="input.php" >
                    UPDATE RECORD
                   
                    </a>
                </li>                
                




<?php include 'footer.php'; ?>
